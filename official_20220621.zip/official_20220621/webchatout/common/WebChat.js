var WebChat = {
    version: "8.0.1.21, 20210730-122059",

    chatId: null,

    lastchatId: null,

    roomId: null,

    location: null,

    isWorkTime: false,

    isInAgentService: false,

    isSurveyFromAgent: false,

    submitedSurvey: "empty",

    isNormalStop: false,

    servicegroupId: null,

    socket: null,

    isEverInAgentService: false,

    messageIndex: 0,

    hintHtmlMap: {},

    tenantCode: "",

    tenantInfo: null,

    pictureId: null,

    Leave: null,

    newMessageTime: null,

    timer: null,

    timercount: 0,

    richmenuObject: null,

    preMessageRecord: [],

    isStorage: true,

    isInQueue: false,

    currentReSendElement: null,

    whileListTags: ["a", "br", "iframe", "p", "img", "label"],

    enableConditions: {},
    
    isSendMsgByUrl: false,

    isNotActive: false,
    
    sendMsgByUrlContent: '',

    authrequest: true, // 20211030 temp
	
	valueotp: null, // 20220324 add parameter to save value from url 
	
	fpidvalue: null, // 20220324 add param to save fpid value

    //-----------------------------------------------------------------------
    // event handlers
    //-----------------------------------------------------------------------

    doLoad: function () {
		
		// 20220620 check webchatout 
		let hn = location.host.toLowerCase(); 
		let pn = location.pathname.toLowerCase();
		if(hn.indexOf('chatbot') != -1 && pn.indexOf('webchatout') != -1){
			WebChat.enableConditions = {
				"ApplyAgentButton": "WebChat.chatId != null && !WebChat.isInAgentService",
				"AttachmentButton": "WebChat.chatId != null && WebChat.isInAgentService",
				"ImageButton": "WebChat.chatId != null && WebChat.isInAgentService",
				"EmojiButton": "WebChat.chatId != null",
				"HotTopicButton": "",
				"ChangeRichMenuButton": Util.getConfig('richMenu'),
				"RightZone": Util.getConfig('contact'),
				"RestartChatButton": "WebChat.chatId == null",
				"EditorZone": "WebChat.chatId != null"
			}
			WebChat.isInAgentService = WebChat.sessionStorage.getItem("isInAgentService") == "true" ? true : false;
			WebChat.isEverInAgentService = WebChat.sessionStorage.getItem("isInAgentService") == "true" ? true : false;
			WebChat.submitedSurvey = WebChat.sessionStorage.getItem("submitedSurvey");

			let history = WebChat.sessionStorage.getItem("historyMessage");
			if (history && history != "null")
				WebChat.preMessageRecord = JSON.parse(history);
			else
				WebChat.preMessageRecord = [];

			WebChat.queryTenantInfo();
		} else {
			WebChat.checkTenantStatus();
			
			return;
		}
    },

    setConfig: function () {

        $("#nvbarTitle").text((Util.getConfig('isShowGWBotName')) ? (WebChat.tenantInfo.botName) ? WebChat.tenantInfo.botName : WebChat.text("Title") : WebChat.text("Title"));

        if (Util.getConfig('isShowLogoImage')) {
            $("#logoImage").attr("src", Util.getConfig("LogoImageUrl") || "image/logo.png");
            $("#logo").show();
        }

        if (Util.getConfig('isShowHelpButton')) {
            WebChat.hintHtmlMap["help"] = WebChat.text("HelpMessage");
            $("#HelpButton").text(WebChat.text("HelpButtonText"));
            $("#HelpButton").attr('aria-label', WebChat.text("HelpButtonText"));
            $("#HelpButton").on('click keypress', function () {
                WebChat.showHint("help");
            });
        } else
            $("#HelpListItem").hide();

        if (Util.getConfig('isHotquestion')) {
            HotTopic.ini();
            $("#HotQuestionButton").text(WebChat.text("FocusTopic"));
            $("#HotQuestionButton").attr('aria-label', WebChat.text("FocusTopic"));
            $("#HotTopicModalTitle").text(WebChat.text("FocusTopic"));
            $("#HotQuestionButton").on('click keypress', function () {
                $("#HotTopicModal").modal('show');
            });
        } else
            $("#HotQuestionListItem").hide();

        if (Util.getConfig('isShowAttentionButton')) {
            WebChat.hintHtmlMap["attention"] = WebChat.text("AttentionMessage");
            $("#AttentionButton").text(WebChat.text("AttentionButtonText"));
            $("#AttentionButton").attr('aria-label', WebChat.text("AttentionButtonText"));
            $("#AttentionButton").on('click keypress', function () {
                WebChat.showHint("attention");
            });
        } else
            $("#AttentionListItem").hide();

        if (Util.getConfig('isShowVersionButton')) {
            WebChat.hintHtmlMap["version"] = WebChat.version;
            $("#VersionButton").text(WebChat.text("VersionButtonText"));
            $("#VersionButton").attr('aria-label', WebChat.text("VersionButtonText"));
            $("#VersionButton").on('click keypress', function () {
                WebChat.showHint("version");
            });
        } else
            $("#VersionListItem").hide();

        if (Util.getConfig('isShowSurveyButton')) {
            $("#SurveyButton").text(WebChat.text("SurveyButtonText"));
            $("#VersionButton").attr('aria-label', WebChat.text("SurveyButtonText"));
            $("#SurveyButton").on('click keypress', WebChat.showSurvey);
        } else
            $("#SurveyListItem").hide();

        if (!Util.getConfig('isShowExitButton'))
            $("#ExitButton").hide();

        if (!Util.getConfig('isShowAgentIcon'))
            $("#ApplyAgentButton").hide();

        if (!Util.getConfig('isShowEmojiIcon'))
            $("#EmojiButton").hide();

        if (Util.getConfig('isShowDropdownMenuIcon')) {
            $("#hamburgerMenu").on('keypress', function () {
                $("#hamburgerMenu").dropdown('toggle');
            })
        } else
            $("#hamburgerMenu").hide();

        if (Util.getConfig('contact')) {
            Auth.doLoad();
            Contact.doLoad();
        } else
            $("#MemberServiceListItem").hide();


        if (Util.getConfig('webCall'))
            WebCallStart.doload();

        if (Util.getConfig('richMenu'))
            RichMenu.Ini();

        if (Util.getConfig('isQueryquestion'))
            WebChat.setAutocomplete();

        if (Util.getConfig('isGetLocation'))
            WebChat.getLocation();

        WebChat.setQueueBtnStatus('hide');
		
		//20210107 linkmenu
		LinkMenu.doload();
		
		// 20220324 add parameter to save value from url 
		WebChat.valueotp = WebChat.getQueryString("value");

        //OTP 輸入身份證字號的 取消鈕 設定
        $("#uIdCancel").click(function() {
			WebChat.addSystemMessageAsDialog(WebChat.text("OtpCancelledByUser"));
			Custom.resetText();
			Custom.resetTime();
			Custom.presentReply = "";
			Custom.isOtpCancelled = true; //已取消OTP 
			$("#uIdAuthModal").modal("hide");
        });
        //OTP 輸入身份證字號及驗證碼的 確認鈕 設定
        $("#uIdAuthGo").click(function() {
            //先檢查身份證是否正確
			console.log("WebChat.chatId: "+ WebChat.chatId);
            if (WebChat.chatId != null) {
                Custom.OTPgraphicVerifyAuth(Custom.otpques);
            } else {
                $("#uIdAuthModal").modal("hide");
                $("#MessageAuth").modal("hide");
            }
        });
        $("#MessageCancel").click(function() { 		
			clearInterval(Custom.timer);
			document.getElementById("errorOTP").innerHTML="";
			$("#uIdText").val("");
			$("#graphicVerifyText").val("");
			document.getElementById("errorMsg").innerHTML="";
			$("#MessageAuthText").val("");
			Custom.errorT=0;
			WebChat.addSystemMessageAsDialog(WebChat.text("OtpCancelledByUser"));
			//Custom.resetText();
			Custom.time=300; //5分鐘=300秒
			Custom.isOtpCancelled = true; //已取消OTP 
			$("#MessageAuth").modal("hide");
        });
        //OTP 輸入簡訊驗證碼  確認鈕 設定
        $("#MessageAuthGo").click(function() {
            if (WebChat.chatId != null) {
                Custom.OTPcodeAuth();
            } else {
                $("#uIdAuthModal").modal("hide");
                $("#MessageAuth").modal("hide");
            }
        });
        // refresh captcha
        $("#changeAuth").click(function() {
            Custom.refreshImage();
        });

        // refresh captcha
        $("#imageAuth").click(function() {
            Custom.refreshImage();
        });
        // Add OTP function by chainsea\alex 20210107 CustomEnd 
    },

    setEditorWidth: function () {
        $("#Editor").css("width",
            parseInt($("#LeftZone").width()) -
            parseInt($(".buttonZone").width()) -
            $("#SendButton")[0].offsetWidth -
            27
        );
    },

    setAutocomplete: function () {
        $("#Editor").autocomplete();
        WebChat.ajax({
            url: Util.getConfig('CRMGatewayUrl') + "openapi/web/message/getAllQuestion",
            data: {
                tenantCode: WebChat.tenantCode
            },
            success: function (ret) {
                console.debug('allQuestion', ret.result);
                let questionData = [];

                for (let key in ret.result) {
                    let items = ret.result[key];
                    questionData.push({
                        
                        label: key,
                        key: key
                    })
                    for (let i = 0; i < items.length; i++) {
                        
                        questionData.push({
                            label: items[i],
                            key: key
                        })
                    }
                }

                let editor = $("#Editor");
                editor.autocomplete({
                    select: function (event, ui) {
                        if (event.keyCode == 13) {
                            $(this).autocomplete("close");
                            return false;
                        }
                    },
                    source: function (request, response) {
                        var results = $.ui.autocomplete.filter(questionData, request.term);
                        let result = [];
                        let filter = [];
                        for (let i = 0; i < results.length; i++) {
                            
                            let key = results[i].key;
                            if (!!~filter.indexOf(key))
                                continue;
                            else {
                                switch (Util.getConfig('queryQuestion_QType')) {
                                    case 'standard':
                                        result.push({
                                            label: results[i].key,
                                            key: results[i].key
                                        });
                                        break;
                                    case 'all':
                                        result.push(results[i]);
                                        break;
                                }
                                filter.push(key);
                            }
                            if (Util.getConfig('QueryquestionLimits') === result.length)
                                break;
                        }
                        console.debug('autoCompleteContent: ', result);
                        response(result);
                    },
                    classes: {},
                });
                editor.autocomplete("option", "position", {
                    my: "top",
                    at: "bottom"
                });
            }
        });
    },

    setRichMenuWidth: function () {
        RichMenu.getRichMenuArea(WebChat.richmenuObject);
        WebChat.refreshMessageListLayout();
    },

    optionClicked: function (optionNo, innerNo) {
        var messageShow = {
            type: Constant.TYPE_TEXT,
            content: "" + optionNo
        };
        var elementId = WebChat.addMessage(messageShow);

        var messageSend = {
            type: Constant.TYPE_TEXT,
            content: "" + innerNo
        };
        WebChat.sendMessage(messageSend, elementId);
    },

    optionSurveyClicked: function (surveyText) {
        var messageShow = {
            type: Constant.TYPE_TEXT,
            content: "" + surveyText
        };
        var elementId = WebChat.addMessage(messageShow);

        var messageSend = {
            type: Constant.TYPE_TEXT,
            content: "" + surveyText
        };
        WebChat.sendMessage(messageSend, elementId);
    },

    linkClicked: function (surveyText) {
        if (WebChat.isEverInAgentService) {
            return false;
        }
        var messageShow = {
            type: Constant.TYPE_TEXT,
            content: "" + surveyText
        };
        var elementId = WebChat.addMessage(messageShow);
        var messageSend = {
            type: Constant.TYPE_TEXT,
            content: "" + surveyText
        };
        WebChat.sendMessage(messageSend, elementId);
    },

    swiper_li_button: function (link) {
        if (WebChat.chatId != null) {
            var messageShow = {
                type: Constant.TYPE_TEXT,
                content: $(link).attr('reply'),
                FCode: $(link).attr("q")
            };
            var elementId = WebChat.addMessage(messageShow);
            var messageSend = {
                type: Constant.TYPE_TEXT,
                content: $(link).attr("q")
            };
            WebChat.sendMessage(messageSend, elementId);
        }
    },

    editorChanged: function (e) {
        if (WebChat.isInAgentService) {
            clearInterval(Custom.timer);
            WebChat.timercount = 0;
            var content = Util.getHtmlValueById("Editor");
            WebChat.timer = setInterval(function () {
                WebChat.timercount++;
                if (WebChat.timercount == 5) {
                    
                    WebChat.sendPreviewMessage(content);
                    WebChat.timercount = 0;
                    clearInterval(WebChat.timer);
                }
            }, 100);
        }
    },

    checkWordLimit: function () {
        var content = $("#Editor").val();
        if (content.length > WebChat.tenantInfo.sendMessageMaxLength) {
            $("#Editor").val(content.substring(0, WebChat.tenantInfo.sendMessageMaxLength));
            alert(WebChat.text("OverInputLimit"));
            return;
        }
    },

    editorKeyUp: function (e) {
        var content = $("#Editor").val();
        if (content.length > 0) {
            if (!$("#SendButton").hasClass('active'))
                $("#SendButton").addClass('active');
        } else {
            $("#SendButton").removeClass('active');
        }
    },

    editorKeyDown: function (e) {
        if (e.shiftKey == true) {
            if (e.keyCode == 13) {
                
            }
        } else {
            if (e.keyCode == 13) {
                e.preventDefault();
                if (Util.getConfig('isQueryquestion'))
                    $(this).autocomplete("close");
                WebChat.doSendButtonClick();
            }
        }
    },

    OpenP4Page: function (url) {
        if (window.parent.EcpWebChatEntry != null) {
            window.parent.EcpWebChatEntry.OpenP4Page(url);
        } else {
            WebChat.OpenInternalP4Page(url);
        }
    },

    OpenInternalP4Page: function (url) {
        $("#ifP4Url").attr("src", url);
        $("#dvP4Page").css("display", "block");
    },

    CloseP4Page: function () {
        $("#ifP4Url").attr("src", "");
        $("#dvP4Page").css("display", "none");
    },

    OpenUrl: function (url) {
        location.href = url;
    },

    doBeforeUnload: function () {
        WebChat.sessionStorage.setItem("isInAgentService", WebChat.isInAgentService);
        WebChat.sessionStorage.setItem("tenantCode", WebChat.tenantCode);
        WebChat.sessionStorage.setItem("submitedSurvey", WebChat.submitedSurvey);
        if (WebChat.tenantInfo)
            WebChat.sessionStorage.setItem("tenantInfo", JSON.stringify(WebChat.tenantInfo));

        if (WebChat.chatId)
            WebChat.sessionStorage.setItem("historyMessage", JSON.stringify(WebChat.preMessageRecord));

        if (Util.getConfig('webCall'))
            WebCallStart.webcallStop();

        if (WebChat.isInQueue)
            WebChat.doCancelQueueButtonClick();
        else {
            if (WebChat.socket != null) {
                WebChat.socket.close(4500);
                WebChat.socket = null;
            }
        }
    },

    doApplyAgentButtonClick: function () {
        QuickReply.closeQuickReplyPool();
        if (!WebChat.isButtonEnabled(this)) {
            return;
        }
        
        $("#ApplyAgentButton").attr("disabled", "disabled");
        setTimeout(function () {
            $("#ApplyAgentButton").removeAttr("disabled");
        }, 1000);
        
        /** 檢查是否允許匿名 */
        if (WebChat.tenantInfo.isAnonymousToAgent) {
            
            WebChat.queueZoneModal("show");
            setTimeout(function () {
                WebChat.isAgentWorkTime();
            }, 500);
        } else {
            if (Util.getCookie("tokenId") != undefined && Util.getCookie("tokenId") != null) {
                WebChat.queueZoneModal("show");
                setTimeout(function () {
                    WebChat.isAgentWorkTime();
                }, 500);
            } else {
                Auth.doLoginButtonClick();
            }
            Auth.loginnext = 'toAgent';
        }

    },

    doAttachmentButtonClick: function () {
        if (!WebChat.isButtonEnabled(this)) {
            return;
        }
        $("#fileupload").attr('accept', '');
        $("#fileupload").click();
    },

    doImageButtonClick: function () {
        if (!WebChat.isButtonEnabled(this)) {
            return;
        }
        $("#fileupload").attr('accept', '.gif,.jpeg,.jpg,.png,.tif,.bmp');
        $("#fileupload").click();
    },

    doEmojiButtonClick: function () {
        if (!WebChat.isButtonEnabled(this)) {
            return;
        }
        $("#EmojiButton").StickerEmotion("#Editor");
    },

    doCancelQueueButtonClick: function () {
        WebChat.isInQueue = false;
        WebChat.queueZoneModal("hide");
        WebChat.agentStop();
    },

    setQueueBtnStatus: function (action) {
        
        if (Util.getConfig('isWaitQueue'))
            $("#waitQueue")[action]();
        $("#cancelQueue")[action]();
    },

    doWaitQueueButtonClick: function () {
        $("#waitQueue").hide();

        let showWaitQueueBtnTimeMin = WebChat.tenantInfo.chatTimeoutMinutes - 1;

        setTimeout(function () {
            $("#waitQueue").show();
        }, showWaitQueueBtnTimeMin * 60 * 1000);

        $("#queueZoneModal .wording").text(WebChat.text("ContinueSuccess"));

        var elementId = WebChat.addSystemMessage(WebChat.text("ContinueWaitMessage"));

        var messageSend = {
            type: Constant.TYPE_TEXT,
            content: "#queue?action=continue"
        };
        WebChat.sendMessage(messageSend, elementId);
    },

    doCloseButtonClick: function () {
        var callback = function () {
            WebChat.chatId = null;
            window.close();
        };
        WebChat.ajax({
            url: Util.getConfig('CRMGatewayUr') + "openapi/web/chat/stop",
            data: {
                chatId: WebChat.chatId
            },
            error: callback,
            success: callback
        });
    },

    doSendButtonClick: function (event) {
        if (!WebChat.isButtonEnabled(this)) {
            return;
        }
        if (!WebChat.tenantInfo.isAnonymousToChatBot && Util.getCookie("tokenId") == undefined) {
            Auth.doLoginButtonClick();
            Auth.loginnext = 'sendMessage';
            return;
        }
        var msg = Util.getHtmlValueById("Editor").replace(/<div>/g, "<br>").replace(/<\/div>/g, "");
        var content = Util.unescapeHtml(msg);
        if (content != null && content.trim() != "") {
            $("#Editor").val("");
            $("#SendButton").removeClass('active');
            var message = {
                type: Constant.TYPE_TEXT,
                content: content
            };
            var elementId = WebChat.addMessage(message);
            
            setTimeout(function () {
                if (content == WebChat.tenantInfo.applyAgentCode && WebChat.isInAgentService == false) {
                    WebChat.doApplyAgentButtonClick();
                } else {
                    if (elementId != null)
                        WebChat.sendMessage(message, elementId);
                    if (WebChat.isEverInAgentService) {
                        clearInterval(WebChat.timer); 
                        WebChat.sendPreviewMessage("");
                    }
                }
            }, 100);
        }
    },

    doSendMessage: function (SendMessage) {
        if (!WebChat.isButtonEnabled(this)) {
            return;
        }
        var msg = SendMessage.replace(/<div>/g, "<br>").replace(/<\/div>/g, "");
        var content = Util.unescapeHtml(msg);
        if (content != null && content.trim() != "") {
            var message = {
                type: Constant.TYPE_TEXT,
                content: content
            };

            var elementId = "";
            if (msg.indexOf("faqvote:") != 0)
                elementId = WebChat.addMessage(message);
            else
                elementId = "ChatMessage_" + ++WebChat.messageIndex;

            WebChat.sendMessage(message, elementId);
        }
    },

    doImageClick: function (event) {
        var image = event.srcElement || event.target;
        var url = $(image).attr("url");
        if (!Util.isEmpty(url)) {
            window.open(url);
        }
    },

    doExitButtonClick: function () {
        if (parent.EcpWebChatEntry != null) {
            parent.EcpWebChatEntry.ClosePanel();
        }
    },

    queueZoneModal: function (status) {
        if (status == "show") {
            $("#queueZoneModal").modal("show");
        } else {
            $("#queueZoneModal").modal("hide");
            $("#queueZoneModal .wording").text(WebChat.tenantInfo.applyingAgentWord);
            WebChat.setQueueBtnStatus('hide');
        }
    },
	
	queryZoneModal: function (status) {
        if (status == "show") {
            $("#queryZoneModal").modal("show");
        } else {
            $("#queryZoneModal").modal("hide");
			
            WebChat.setQueueBtnStatus('hide');
        }
    },

    //-----------------------------------------------------------------------
    // chat control functions
    //-----------------------------------------------------------------------

    
    checkTenantStatus: function (res) {
        if (res && res.resultInfo) {
            const tenantInfo = res.resultInfo;
            if (tenantInfo.success) {
                WebChat.tenantInfo = res.tenantInfo;
                return true;
            } else {
                
                const chatId = WebChat.sessionStorage.getItem("chatId");
                WebChat.tenantInfo = JSON.parse(WebChat.sessionStorage.getItem("tenantInfo")) || null;
                if (chatId == null || chatId == undefined)
                    WebChat.isNotActive = true;
                switch (tenantInfo.errorCode.toString()) {
                    case '10201':
                        localStorage.setItem('TenantErrMsg', tenantInfo.errorMessage || WebChat.text('Termination'));
                        location.href = Util.getConfig('WebChatUrl') + 'inactive.html?tenantCode=' + WebChat.tenantCode;
                        break;
                    case '10207':
                        localStorage.setItem('TenantErrMsg', tenantInfo.errorMessage || WebChat.text('Termination'));
                        if (chatId == null || chatId == undefined)
                            location.href = Util.getConfig('WebChatUrl') + 'inactive.html?tenantCode=' + WebChat.tenantCode;
                        else
                            WebChat.notActiveUrl = Util.getConfig('WebChatUrl') + 'inactive.html?tenantCode=' + WebChat.tenantCode;
                        break;
                    case '10208':
                        localStorage.setItem('TenantErrMsg', tenantInfo.errorMessage || WebChat.text('Termination'));
                        if (chatId == null || chatId == undefined)
                            location.href = Util.getConfig('WebChatUrl') + 'inactive.html?tenantCode=' + WebChat.tenantCode;
                        else
                            WebChat.notActiveUrl = Util.getConfig('WebChatUrl') + 'inactive.html?tenantCode=' + WebChat.tenantCode;
                        break;
                    default:
                        localStorage.setItem('TenantErrMsg', WebChat.text('Termination'));
                        location.href = Util.getConfig('WebChatUrl') + 'inactive.html?tenantCode=' + WebChat.tenantCode;
                        break;
                }
                return false;
            }
        } else {
            localStorage.setItem('TenantErrMsg', WebChat.text('Termination'));
            location.href = Util.getConfig('WebChatUrl') + 'inactive.html?tenantCode=' + WebChat.tenantCode;
            return false;
        }
    },

    queryTenantInfo: function (reason) {
        if (WebChat.tenantCode != null) {
            WebChat.ajax({
                url: Util.getConfig('CRMGatewayUrl') + "openapi/web/ivr/tenantInfo",
                async: false,
                data: {
                    _header_: {
                        tokenId: "",
                        language: Util.getConfig('language')
                    },
                    tenantCode: WebChat.tenantCode
                },
                error: function (e) {
                    WebChat.checkTenantStatus();
                },
                success: function (ret) {
                    if ((WebChat.checkTenantStatus(ret) || !WebChat.isNotActive)) {
                        if (reason !== 'restart') {
                            let html =
                                '<div style="display: none;">' +
                                '<label for="fileupload"></label>' +
                                '<label for="avatarupload"></label>' +
                                '<label for="imgupload1"></label>' +
                                '<label for="imgupload2"></label>' +
                                '<label for="imgupload3"></label>' +
                                '<input id="fileupload" type="file" name="file[]" multiple tabindex="-1" title="fileupload">' +
                                '<input id="avatarupload" type="file" name="file" accept="image/*" tabindex="-1" title="avatarupload">' +
                                '<input id="imgupload1" type="file" name="file1" accept="image/*" tabindex="-1" title="imgupload1">' +
                                '<input id="imgupload2" type="file" name="file2" accept="image/*" tabindex="-1" title="imgupload2">' +
                                '<input id="imgupload3" type="file" name="file3" accept="image/*" tabindex="-1" title="imgupload3">' +
                                '</div>'
                            $("#upload_div").append(html);
                            File.initialize();
                            Stickertable.doLoad();
                            QuickReply.initQuickReplyPool();

                            $("#StopChatButton").text(WebChat.text("StopChatButton"));
                            $("#StopChatButton").attr('aria-label', WebChat.text("StopChatButton"));
                            $("#StopChatButton").on('click keypress', function () {
                                sessionStorage.removeItem("chatId");
                                WebChat.stopChat();
                            });

                            $("#RestartChatButton").on('click keypress', function () {
                                WebChat.restartChat();
                            });

                            $("#dvSurveyModalBody").html(Survey.getForm(WebChat.isInAgentService));
                            $("#submitSurveyButton").text(WebChat.text("Ok"));
                            $("#SurveyModalTitle").html(WebChat.text("SurveyButtonText"));


                            $("#submitSurveyButton").click(function () {
                                Survey.submitSurvey();
                            });

                            $("#ExitButton").on('keypress click', WebChat.doExitButtonClick);

                            $("#ApplyAgentButton").attr("title", WebChat.text("ApplyAgentButtonHint"));
                            $("#ApplyAgentButton").on('click keypress', WebChat.doApplyAgentButtonClick);

                            $("#AttachmentButton").attr("title", WebChat.text("UploadFile"));
                            $("#AttachmentButton").on('click keypress', WebChat.doAttachmentButtonClick);

                            $("#ImageButton").attr("title", WebChat.text("ImageButtonHint"));
                            $("#ImageButton").on('click keypress', WebChat.doImageButtonClick);

                            $("#EmojiButton").attr("title", WebChat.text("EmojiButtonHint"));
                            $("#EmojiButton").click(WebChat.doEmojiButtonClick);

                            $("#CloseButton").text(WebChat.text("Close"));
                            $("#CloseButton").on('click keypress', WebChat.doCloseButtonClick);

                            $("#SendButton").on('click keypress', WebChat.doSendButtonClick);

                            $("#Editor").keyup(WebChat.editorKeyUp);
                            $("#Editor").keydown(WebChat.editorKeyDown);
                            $("#Editor").attr("placeholder", WebChat.text("EditorPlaceHolder"));
                            
                            $("#Editor").on('input', WebChat.editorChanged);

                            $('.modal').on('hidden.bs.modal', function (e) {
                                $('input', this).val("");
                            });

                            
                            $("#LeaveWordModalTitle").html(WebChat.text("LeaveWord"));
                            $("#LeaveWordButton").on('click keypress', LeaveWord.send);
                            $("#LeaveWordClose").on('click keypress', LeaveWord.close);

                            $("#btnP4PageClose").on('click keypress', WebChat.CloseP4Page);

                            
                            $(document).on('keypress click', '.navbar-collapse.in', function (e) {
                                if ($(e.target).is('a') && $(e.target).attr('class') != 'dropdown-toggle')
                                    $(this).collapse('hide');
                            });

                            $(window).on('resize', function () {
                                WebChat.setEditorWidth();
                                WebChat.setRichMenuWidth();
                            });

                            WebChat.setConfig();
                            WebChat.checkisChatIdExist();
                        } else {
                            WebChat.startChat();
                        }
                    }
                }
            });
        }
    },

    isAgentWorkTime: function () {
        WebChat.ajax({
            url: Util.getConfig('CRMGatewayUrl') + "openapi/web/agent/isworktime",
            async: false,
            data: {
                chatId: WebChat.chatId
            },
            success: function (ret) {
                if (ret.isWorkTime) {
                    WebChat.selectServiceGroup();
                } else {
                    WebChat.addSystemMessageAsDialog(WebChat.tenantInfo.notInServiceTimeHint);
                    WebChat.queueZoneModal("hide");
                }
            },
            error: function (e) {
                if (e.statusText && !!~e.statusText.indexOf("NetworkError"))
                    WebChat.addSystemMessage(WebChat.text('NetWorkAbortError'), true);
                else
                    console.debug("Connection to ECP Server refused. ErrorMsg: " + e);
                WebChat.queueZoneModal("hide");
            }
        });
    },

    startChat: function () {
        let cookieId = Util.getCookie("cookieId");
        if (!cookieId) {
            cookieId = Random.nextUuid();
            Util.setCookie("cookieId", cookieId);
        }

        WebChat.ajax({
            url: Util.getConfig('CRMGatewayUrl') + "openapi/web/chat/start",
            async: false,
            data: {
                _header_: {
                    tokenId: "",
                    language: Util.getConfig('language')
                },
                from: Util.getConfig('from'),
                tenantCode: WebChat.tenantCode,
                moduleType: WebChat.tenantInfo.moduleType,
                fromDevice: Util.getConfig('fromDevice'),
                fromTitle: Util.getConfig('fromTitle'),
                fromUrl: Util.getConfig('fromUrl'),
                treeId: "001",
                rootTreeId: "001",
                identifyBy: Util.getCookie('identifyBy') || Util.getConfig('identifyBy'),
                identifyValue: Util.getCookie("identifyValue") || "GUEST",
                cookieId: cookieId
            },
            error: function (e) {
                if (e.statusText && !!~e.statusText.indexOf("NetworkError"))
                    WebChat.addSystemMessage(WebChat.text('NetWorkAbortError'), true);
                else
                    WebChat.addSystemMessage('StartChatErrorMessage', true);
                console.debug('StartChatErrorMessage:', e);
            },
            success: function (ret) {
                if (ret._header_) {
                    if (ret._header_.success) {
                        console.debug("[chat/start] chatId = %s", ret.chatId);
                        $("#webmakecallbtn").hide();
                        WebChat.isNormalStop = false;
                        WebChat.chatId = ret.chatId;
                        WebChat.lastchatId = ret.chatId;
                        WebChat.isSurveyFromAgent = false;
                        WebChat.submitedSurvey = "empty";
                        WebChat.sessionStorage.setItem("chatId", WebChat.chatId);
                        WebChat.sessionStorage.setItem("submitedSurvey", WebChat.submitedSurvey);
                        WebChat.jocketInit();
                        WebChat.isInAgentService = false;
                        WebChat.isEverInAgentService = false;
                        WebChat.configEnableConditions();
                        if (Util.getConfig('contact'))
                            Contact.transferToAgent(ret);
                        else
                            WebChat.addGreeting(ret);

                        WebChat.otcInit();
                        WebChat.refreshButtonStatus();
                    }
                } else
                    WebChat.checkTenantStatus(ret);
				
				// Add OTP function by chainsea\alex 20210107 CustomStart 
				Custom.doLoad(); // otp use
            }
        });
    },

    
    sendMsgByUrl: function () {
        if (!WebChat.tenantInfo.isAnonymousToChatBot && Util.getCookie("tokenId") == undefined) {
            WebChat.isSendMsgByUrl = true;
            Auth.doLoginButtonClick();
            return;
        } else {
            const urlType = Util.getParameterByName('type');

            if (urlType === 'send' && !!WebChat.sendMsgByUrlContent) {
                if (WebChat.sendMsgByUrlWording)
                    WebChat.addSystemMessage(WebChat.sendMsgByUrlWording);

                WebChat.sendMessage({
                    type: 'text',
                    content: WebChat.sendMsgByUrlContent
                })
            }
            WebChat.isSendMsgByUrl = true;
        }
    },

    
    otcInit: function () {
        WebChat.sendMsgByUrlWording = WebChat.text('OtcInit');
        WebChat.sendMsgByUrl();
    },

    configEnableConditions: function () {
        if (WebChat.chatId && Util.getConfig('richMenu'))
            WebChat.getRichMenu();

        if (Util.getConfig('contact'))
            Auth.changeLoginDisplay();
        else {
            $("#LoginButton").css('display', 'none');
            $("#RightZone").remove();
        }
    },

    getRichMenu: function () {
        WebChat.ajax({
            url: Util.getConfig('CRMGatewayUrl') + "openapi/gateway/richmenu/getRichMenu",
            async: false,
            data: {
                _header_: {
                    tokenId: "",
                    language: Util.getConfig('language')
                },
                tenantCode: WebChat.tenantCode,
                channel: Util.getConfig('from')
            },
            success: function (ret) {
                WebChat.richmenuObject = ret.richmenu;
                if (ret.richmenu.hasOwnProperty("imageUrl"))
                    RichMenu.create();
            }
        });
    },

    jocketInit: function () {
        WebChat.socket = new Jocket({
            server: Util.getConfig('CRMGatewayUrl'),
            path: "/jocket/gw/webchat",
            params: {
                chatId: WebChat.chatId
            },
            upgrade: false
        });
        WebChat.socket.on("open", WebChat.doSocketOpen);
        WebChat.socket.on("close", WebChat.doSocketClose);
        WebChat.socket.on("message", WebChat.doSocketMessage);
    },

    addGreeting: function (ret) {
        if (ret.senderType.toLowerCase() == "icr") {
            WebChat.addMessage({
                category: Constant.CATEGORY_CHAT,
                senderType: "icr",
                type: Constant.TYPE_TEXT,
                content: ret.content
            });
        } else {
            var greetingWords = ret.greeting;
            if (ret.type !== 'Multiple') {
                if (ret.type == "Image")
                    greetingWords = Util.JsonParse(greetingWords);

                WebChat.addMessage({
                    category: Constant.CATEGORY_CHAT,
                    senderType: Constant.SENDER_TYPE_ROBOT,
                    type: ret.type,
                    content: greetingWords
                });
            } else {
                let parseGreetingContent = Util.JsonParse(greetingWords);
                WebChat.addMultipleMessage(parseGreetingContent, ret, 'greeting');
            }
            $("#ApplyAgentButton").removeClass("ButtonDisabled");
        }
    },

    checkisChatIdExist: function (type) {
        var chatId = WebChat.sessionStorage.getItem("chatId");
        var tenantCode = WebChat.sessionStorage.getItem("tenantCode");
        if (chatId == null || chatId == undefined || tenantCode != WebChat.tenantCode) {
            WebChat.startChat();
            return;
        }
        WebChat.ajax({
            url: Util.getConfig('CRMGatewayUrl') + "openapi/web/chat/isChatIdExist",
            async: false,
            data: {
                chatId: chatId
            },
            error: function () {
                WebChat.startChat();
            },
            success: function (ret) {
                WebChat.chatId = chatId;
                var closeReason = ret.hasOwnProperty("closeReason") ? ret.closeReason : "";
                WebChat.reviewMessage(closeReason);

                if (ret.isChatIdExist) {
                    WebChat.lastchatId = chatId;
                    var timeoutID = setTimeout(function () {
                        WebChat.createNewJocket();
                    }, 1000);
                    WebChat.refreshButtonStatus();
                } else if (WebChat.isNotActive) {
                    location.href = WebChat.notActiveUrl;
                } else {
                    WebChat.chatId = null;
                    WebChat.sessionStorage.removeItem("chatId");
                    WebChat.sessionStorage.removeItem("historyMessage");
                    WebChat.isNormalStop = true;
                    WebChat.refreshButtonStatus();
                }
                WebChat.configEnableConditions();
            }
        });
    },

    createNewJocket: function () {
        WebChat.socket = new Jocket({
            server: Util.getConfig('CRMGatewayUrl'),
            path: "/jocket/gw/webchat",
            params: {
                chatId: WebChat.chatId
            },
            upgrade: false,
        });

        WebChat.socket.on("open", WebChat.doSocketOpen);
        WebChat.socket.on("close", WebChat.doSocketClose);
        WebChat.socket.on("message", WebChat.doSocketMessage);
    },

    reviewMessage: function (closeReason) {
        for (let item in WebChat.preMessageRecord) {
            var message = WebChat.preMessageRecord[item];
            let elementId = WebChat.addMessage(message, true);
            if (message.disconnectStatus.split('_')[2] == 'true')
                WebChat.setMessageFailed(elementId, true);
        }
        if (closeReason) {
            WebChat.createNewJocket();
        }
    },

    recordMessageFormat: function (message) {
        let content = message.content;
        if (message.type == Constant.TYPE_IMAGE || message.type == Constant.TYPE_STICKER || message.type == Constant.TYPE_FILE) {
            if (Util.isJSON(message.content))
                content = JSON.parse(message.content);
        }
        return content;
    },

    stopChat: function (data) {
        if (WebChat.chatId != null) {
            WebChat.ajax({
                url: Util.getConfig('CRMGatewayUrl') + "openapi/web/chat/stop",
                data: {
                    _header_: {
                        tokenId: "",
                        language: Util.getConfig('language')
                    },
                    chatId: WebChat.chatId
                },
                async: false,
                success: function (ret) {
                    WebChat.stopEvent(data);
                }
            });
        }
    },

    stopEvent: function (data) {
        
        $("#ChatMessage_" + WebChat.messageIndex).addClass("timeout");
        WebChat.sessionStorage.removeItem("chatId");
        WebChat.sessionStorage.removeItem("historyMessage");
        WebChat.sessionStorage.removeItem("chatRoomInfo");

        WebChat.isNormalStop = true;
        WebChat.chatId = null;
        WebChat.socket.close();
        WebChat.socket = null;
        WebChat.isInAgentService = false;
        WebChat.isInQueue = false;
        WebChat.refreshButtonStatus();
        WebChat.queueZoneModal("hide");
        $("#ToolZone").hide();

        if (Util.getConfig('webCall'))
            WebCallStart.webcallStop();

        
        if (data !== 'pushMessageTimeout') {
            
            if (data == undefined || (!data.reason && data.type != "Timeout")) {
                WebChat.addSystemMessageAsDialog(WebChat.text("StopChat"));
            } else if (data.reason == "Harass") {
                senderType = Constant.SENDER_TYPE_AGENT;
                if (data._header_.time)
                    WebChat.addSystemMessageAsDialog(WebChat.tenantInfo.agentStopServiceWord, senderType, data._header_.time);
                else
                    WebChat.addSystemMessageAsDialog(WebChat.tenantInfo.agentStopServiceWord, senderType);
            } else {
                senderType = Constant.SENDER_TYPE_ROBOT;
                WebChat.addSystemMessageAsDialog(data.description, senderType);
            }
        }
        WebChat.preMessageRecord = [];
    },

    chatUpdate: function () {
        var identifyValue = Util.getCookie("identifyValue");
        var identifyBy = Util.getCookie("identifyBy");
        WebChat.ajax({
            url: Util.getConfig('CRMGatewayUrl') + "openapi/web/chat/update",
            data: {
                chatId: WebChat.chatId,
                identifyValue: identifyValue,
                identifyBy: identifyBy
            },
            success: function (ret) {
                if (Auth.loginnext == "toAgent")
                    WebChat.doApplyAgentButtonClick();
                if (Auth.loginnext == "sendMessage")
                    $("#SendButton").click();
                Auth.loginnext = "";
            }
        });
    },

    restartChat: function () {
        $("#MessageList").html("");
        $("#SendButton").click(WebChat.doSendButtonClick);
        WebChat.isInAgentService = false;
        WebChat.isEverInAgentService = false;
        WebChat.sessionStorage.removeItem("chatId");
        WebChat.sessionStorage.removeItem("historyMessage");
        WebChat.preMessageRecord = [];
        WebChat.messageIndex = 0;
        WebChat.queryTenantInfo('restart');
    },

    selectServiceGroup: function () {
        
        var select = true;
        WebChat.ajax({
            url: Util.getConfig('CRMGatewayUrl') + "openapi/web/servicegroup/list",
            data: {
                "chatId": WebChat.chatId,
            },
            error: "ServiceGroupErrorMessage",

            success: function (ret) {
                if (ret.groups.length == 0) {
                    WebChat.addSystemMessageAsDialog(WebChat.tenantInfo.noServiceGroup);
                    WebChat.queueZoneModal("hide");
                } else if (ret.groups.length == 1) {
                    WebChat.applyAgent(ret.groups[0].id);
                } else {
                    
                    for (var i = 0; i < ret.groups.length; ++i) {
                        var group = ret.groups[i];
                        if ((Contact.servicetoAgent && group.id == Contact.groupId) || Util.getConfig('groupId') == group.id || Util.getConfig('groupId') == group.name) {
                            WebChat.applyAgent(group.id);
                            select = false;
                        }
                    }
                    if (select == true)
                        ServiceGroupSelect.show(ret.groups, WebChat.applyAgent);
                }
            }
        });
    },

    gotoLeaveWord: function () {
        LeaveWord.show();
    },

    agentStop: function () {
        WebChat.ajax({
            url: Util.getConfig('CRMGatewayUrl') + "openapi/web/agent/stop",
            data: {
                "chatId": WebChat.chatId
            },
            error: function () {

            },
            success: function (ret) {
                console.debug("stop agent");
            }
        })
    },

    applyAgent: function (serviceGroup) {
        WebChat.queueZoneModal("show");

        var data = {
            chatId: WebChat.chatId,
            serviceGroup: serviceGroup,
            identifyBy: "FPId",
            identifyValue: "GUEST",
            fromUrl: Util.getConfig('fromUrl'),
            fromTitle: WebChat.text("SourceUrl"),
            customData: {
                fromDevice: "web",
                fromTitle: Util.getConfig('fromTitle'),
                fromUrl: Util.getConfig('fromUrl'),
            }
        };

        if (Util.getCookie("tokenId") != undefined) {
            data.identifyBy = Util.getCookie("identifyBy");
            data.identifyValue = Util.getCookie("identifyValue");
        }
        
        if (Contact.servicetoAgent == true) {
            
            data.customData.unitId = "32c8c225-2422-4a20-9e4d-1947f0548a1a";
            data.customData.entityId = Contact.entityId;
        }

        if (Util.getConfig('entityId') != "") {
            data.customData.unitId = Util.getConfig('unitId');
            data.customData.entityId = Util.getConfig('entityId');
            data.identifyBy = Util.getConfig('identifyBy');
            data.identifyValue = Util.getConfig('identifyValue');
            data.identifyValue = Util.getConfig('identifyValue');
            data.statusId = Util.getConfig('statusId');
        }
		
		if(Custom.OTPStstus == true){
			// already otp OK 
			data.identifyBy = "FPId"; 
			data.identifyValue = Custom.uId; 
		}

        WebChat.ajax({
            url: Util.getConfig('CRMGatewayUrl') + "openapi/web/agent/apply",
            data: data,
            error: function () {
                WebChat.addSystemMessage(WebChat.text("ApplyAgentErrorMessage"));
                WebChat.queueZoneModal("hide");
                WebChat.refreshButtonStatus();
            },
            success: function (ret) {
                console.debug("[agent/apply] applying, please wait...");
                WebChat.roomId = ret.roomId;
                console.debug("roomId = " + ret.roomId);
                
                if (Contact.getServiceItemData != "" && Contact.servicetoAgent) {
                    WebChat.addSystemMessage(WebChat.text("ServiceRequest") + ": " + Contact.getServiceItemData.FName);
                    Contact.getServiceItemData = "";
                    Contact.servicetoAgent = false;
                }
                if (ret.chatId != null) {
                    WebChat.chatId = ret.chatId;
                }
                if (ret.isNeedToLeaveMessage) {
                    LeaveWord.messageBox(ret.leaveMessageUrl);
                    WebChat.sendRecievedMessage(ret);
                }
                if (ret.roomId == "") {
                    WebChat.doCancelQueueButtonClick();
                    WebChat.addMessage({
                        category: "am",
                        senderType: "robot",
                        type: "Text",
                        content: WebChat.text("QueueExceeded")
                    });
                }
                WebChat.refreshButtonStatus();
            }
        })
    },

    disconnectIconClick: function (element, data) {
        WebChat.currentReSendElement = element.offsetParent;
        $("#ReSendModal").modal("show");
    },

    disconnectAction: function (action) {
        let deleteElementId = WebChat.currentReSendElement.id;
        switch (action) {
            case 'resend':
                WebChat.preMessageRecord.map(function (v) {
                    if (v.disconnectStatus.indexOf(deleteElementId + '_true') != -1) {

                        let addMessageInfo = {
                            type: v.type,
                            content: v.content
                        };

                        let sendMessageInfo = {
                            type: v.type,
                            content: v.content
                        }
                        if ('FCode' in v) {
                            addMessageInfo['FCode'] = v.FCode;
                            sendMessageInfo['content'] = v.FCode;
                        }

                        let elementId = WebChat.addMessage(addMessageInfo);
                        if (elementId != null)
                            WebChat.sendMessage(sendMessageInfo, elementId);
                    }
                });
                WebChat.removeMessage(deleteElementId);
                break;
            case 'delete':
                WebChat.removeMessage(deleteElementId);
                break;
            default:
                break;
        }
    },

    removeMessage: function (deleteElementId) {
        let deletePosition;
        WebChat.preMessageRecord.map(function (v, index) {
            let elementId = v.disconnectStatus.split('_')[0] + '_' + v.disconnectStatus.split('_')[1];
            if (elementId == deleteElementId)
                deletePosition = index;

            if (index > deletePosition)
                WebChat.preMessageRecord[index - 1] = v;

            if (index == WebChat.preMessageRecord.length - 1) {
                WebChat.preMessageRecord.length = index;
            }
        });
        $("#" + deleteElementId).remove();
    },

    sendMessage: function (message, elementId, from) {
        let content = message.content;
        QuickReply.closeQuickReplyPool();
        if (Util.isJSON(content)) {
            content = typeof content !== "string" ? JSON.stringify(content) : content;
            try {
                content = JSON.parse(content);
                
                if (content.type) {
                    switch (content.type) {
                        case 'pushRegistrationBtn':
                            if (WebChat.tenantInfo.socialMediaAlert) {
                                if (!Util.getCookie("tokenId")) {
                                    Auth.doLoginButtonClick();
                                    return;
                                }
                            }
                            break;
                        case 'trf':
                            if (!WebChat.isInAgentService)
                                WebChat.queueZoneModal("show");
                            break;
                        default:
                            if (content == WebChat.tenantInfo.applyAgentCode && !WebChat.isInAgentService) {
                                WebChat.doApplyAgentButtonClick();
                                return;
                            }
                            break;
                    }
                }
            } catch (e) {}
        } else if (content.indexOf("#pushRegistrationBtn") == 0 && WebChat.tenantInfo.socialMediaAlert) {
            if (!Util.getCookie("tokenId")) {
                Auth.doLoginButtonClick();
                return;
            }

        } else if (content.indexOf("#trf") == 0 && !WebChat.isInAgentService) {
            WebChat.queueZoneModal("show");
        } else if (content == WebChat.tenantInfo.applyAgentCode && !WebChat.isInAgentService) {
            WebChat.doApplyAgentButtonClick();
            return;
        }
        message.chatId = WebChat.chatId;
        if (WebChat.socket == null) {
            message.chatId = null;
        }

        if (Util.getCookie("identifyValue") != undefined) {
            message.identifyBy = Util.getCookie("identifyBy")
            message.identifyValue = Util.getCookie("identifyValue");
        } else {
            message.identifyBy = Util.getConfig('identifyBy');
            message.identifyValue = Util.getConfig('identifyValue');
        }

        message.from = Util.getConfig('from');
        WebChat.ajax({
            url: Util.getConfig('CRMGatewayUrl') + "openapi/web/message/send",
            data: message,
            error: function () {
                if (elementId != null) {
                    if (from == 'fileUpload' || from == 'imageUpload') {
                        WebChat.removeMessage(elementId);
                        File.showSystemResult('fail');
                    } else {
                        WebChat.setMessageFailed(elementId, true);
                    }
                    WebChat.queueZoneModal("hide");
                }
            },
            success: function (ret) {
                
                if (ret.isNeedToLeaveMessage) {
                    LeaveWord.messageBox(ret.leaveMessageUrl);
                    return;
                }
                
                if (from == 'fileUpload' || from == 'imageUpload')
                    File.showSystemResult('success');
                
                WebChat.preMessageRecord.map(function (v) {
                    if (v.disconnectStatus == elementId) {
                        v['disconnectStatus'] = elementId + '_false';
                    }
                });

				// OTP trigger CustomStart 
                if(ret.result[0].content.toLowerCase().indexOf("authrequest") >= 0){
                //if(WebChat.authrequest){ // 20211030 temp 
                    Custom.StartOTP(ret.result[0].content.split("|")[1]);
                } else if(ret.result[0].content.toUpperCase().indexOf("E023") != -1){
					WebChat.addSystemMessageAsDialog(WebChat.text("E023"));
                } else if(ret.result[0].content.toUpperCase().indexOf("E060") != -1){
					WebChat.addSystemMessageAsDialog(WebChat.text("E060"));
                } else{ // OTP trigger Custom 
				
					if (ret.result && ret.hasOwnProperty("result")) {
						ret.result.forEach(function (item, index, array) {
							let parseContent = Util.JsonParse(item.content);
							switch (item.type) {
								case 'Multiple':
									
									WebChat.addMultipleMessage(parseContent, item, 'messageSend');
									break;
								case 'QuickReply':
									
									if (parseContent.QuickReply && parseContent.QuickReply.WebViewUrl)
										item['webViewUrl'] = parseContent.QuickReply.WebViewUrl;
									WebChat.addMessage(item);
									break;
								default:
									WebChat.addMessage(item);
									break;
							}
						});
					} else {
						if (ret.chatId != null) {
							WebChat.chatId = ret.chatId;
						}
						if (ret.needAgent) {
							WebChat.addMessage({
								category: Constant.CATEGORY_CHAT,
								senderType: Constant.SENDER_TYPE_ROBOT,
								type: Constant.TYPE_TEXT,
								content: ret.content
							});
						} else if (ret.content != null) {
							if (ret.type == "Image") {
								ret.content = JSON.parse(ret.content);
							}
							WebChat.addMessage(ret);
							console.debug('MessageSendAPI response: ', ret);
						}
					}
					
				} // OTP trigger CustomEnd
            }
        });
    },

    //-----------------------------------------------------------------------
    // other chat API
    //-----------------------------------------------------------------------

    getLocation: function () {
        if (navigator.geolocation) {
            
            navigator.geolocation.getCurrentPosition(
                function (position) {
                    WebChat.location = position.coords;
                    WebChat.updateLocation();
                },
                function (error) {
                    console.error("get location failed. error" + error);
                }
            );
        }
    },

    updateLocation: function () {
        if (WebChat.chatId == null) {
            setTimeout(WebChat.updateLocation, 2000);
            return;
        }
        let longitude = parseFloat(WebChat.location.longitude) ? parseFloat(WebChat.location.longitude) : 0;
        let latitude = parseFloat(WebChat.location.latitude) ? parseFloat(WebChat.location.latitude) : 0;

        var data = {
            chatId: WebChat.chatId,
            location: {
                longitude: longitude,
                latitude: latitude
            }
        };
        WebChat.ajax({
            url: Util.getConfig('CRMGatewayUrl') + "openapi/web/location/update",
            data: data,
            error: function () {
                console.error("update location failed.")
            }
        });
    },

    submitSurvey: function (data) {
        data.chatId = WebChat.lastchatId;
        WebChat.ajax({
            url: Util.getConfig('CRMGatewayUrl') + "openapi/web/survey/score",
            data: data,
            error: "SurveyErrorMessage",
            success: function () {
                Survey.clearSurveyForm();
                WebChat.addSystemMessage(WebChat.text("SurveySuccessMessage"));
                $("#SurveyListItem").hide();
                WebChat.submitedSurvey = WebChat.isInAgentService == true ? "all" : "robot";
            }
        });
    },

    //-----------------------------------------------------------------------
    // message list functions
    //-----------------------------------------------------------------------

    addSystemMessage: function (content, notSave) {
        let id = WebChat.addMessage({
            category: Constant.CATEGORY_SYSTEM,
            content: content
        }, notSave);
        return id;
    },

    addSystemMessageAsDialog: function (message, senderType, time) {
        var message = {
            type: Constant.TYPE_TEXT,
            senderType: senderType || Constant.SENDER_TYPE_ROBOT,
            content: message,
        };
        if (time)
            message['time'] = time;
        WebChat.addMessage(message);
    },

    addMessage: function (message, notSave) {
        
        QuickReply.closeQuickReplyPool();
        WebChat.newMessageTime = new Date().getTime();
        var category = (message.category || Constant.CATEGORY_CHAT).toLowerCase();
        var senderType = (message.senderType || Constant.SENDER_TYPE_USER).toLowerCase();
        var type = (message.type == "QuickReply") ? Util.JsonParse(message.content).QuickReply.type || Constant.TYPE_TEXT : message.type || Constant.TYPE_TEXT;
        var content = message.content;
        var time = Util.formatDate(new Date(), "HH:mm:ss");
        var sender = (message.sender) ? message.sender : "";
        var messageList = document.getElementById("MessageList");
        var id = "ChatMessage_" + ++WebChat.messageIndex;

        
        if (!!message.time) {
            if (typeof (message.time) == 'number')
                time = Util.formatDate(new Date(message.time), "HH:mm:ss");
            else
                time = Util.formatStringDate(message.time);
        } else if (!!message.messageTime) {
            if (!!Monitor.mode)
                time = message.messageTime;
            else
                time = Util.formatStringDate(message.messageTime);
        } else message.messageTime = Util.formatDate(new Date());

        if (typeof (content) !== "object") {
            var regex = /\[(\s=|=)*[^\[\]]*\]([^\[\]]+)\[\/link\]/g;
            var upper = function (match, p1) {
                return match.replace(/\\"/g, "'").replace(/"/g, "'");
            }
            content = content.replace(regex, upper);
            if (Util.isJSON(content))
                content = JSON.parse(content);
        }
        
        if (message.type == "QuickReply") {
            content = content.QuickReply;
        }

        if (category == Constant.CATEGORY_SYSTEM) {
            var html = "<div class=ChatSystemMessage id=" + id + ">";
            $(html).html(message.content + '<br>' + time).appendTo(messageList);
        } else if (category == Constant.CATEGORY_AD) {
            if (!notSave && message.hasOwnProperty('time') && ((WebChat.lastReceivedTime - new Date(message.time).getTime()) > 0))
                notSave = true;
            else
                AnswerDisplay.setAdvertisement(id, content, messageList);
        } else {
            var align = senderType == Constant.SENDER_TYPE_USER ? "Right" : "Left";
            var senderClass = Util.upperFirstLetter(senderType);
            var contentHtml = "";
            if (senderType.toLowerCase() == 'textivr') {
                
                if (message.dataType == 'answer') {
                    
                    var url = message.answerDetail.url;
                    var imageUrl = message.answerDetail.imageUrl;
                    if (!Util.isEmpty(url)) {

                        contentHtml = "<div class='ChatMessageContent ChatMessageTextContent'>" +
                            WebChat.text("HasOpenTheUrl") + "<br>" +
                            "<a target=_blank href='" + url + "'>" + url + "</a>" +
                            "</div>";

                        if (!Util.isEmpty(url)) {
                            window.open(url);
                        }
                    }
                    
                    if (!Util.isEmpty(imageUrl)) {
                        contentHtml = contentHtml + "<div class='ChatMessageContent ChatMessageTextContent'>" +
                            "<img width='100%' height='100%' src='" + imageUrl + "' alt=" + WebChat.text("PictureWithLink") + "/>" +
                            "</div>";
                    }
                    
                    if (!Util.isEmpty(content)) {
                        contentHtml = contentHtml + "<div class='ChatMessageContent ChatMessageTextContent'>" +
                            +WebChat.processTextContent(content) +
                            "</div>";
                    }
                } else {
                    
                    if (content == Constant.CONTENT_TYPE) {
                        $.when(WebChat.getleaveword()).done(function () {
                            contentHtml = "<div class='ChatMessageContent ChatMessageTextContent'>" +
                                WebChat.processTextContent(WebChat.Leave) +
                                "</div>";
                        });
                    } else {
                        contentHtml = "<div class='ChatMessageContent ChatMessageTextContent'>" +
                            WebChat.processTextContent(content) +
                            "</div>";
                    }
                }
            } else {
                
                switch (type) {
                    case Constant.TYPE_TEXT:
                        contentHtml = AnswerDisplay.setTextHTML(content);
                        break;
                    case Constant.TYPE_IMAGE:
                        contentHtml = AnswerDisplay.setImageHTML(content);
                        setTimeout(function () {
                            messageList.scrollTop = messageList.scrollHeight;
                        }, 500);
                        break;
                    case Constant.TYPE_LINKIMAGE:
                        contentHtml = AnswerDisplay.setLinkImageHTML(content);
                        setTimeout(function () {
                            messageList.scrollTop = messageList.scrollHeight;
                        }, 500);
                        break;
                    case Constant.TYPE_STICKER:
                        contentHtml = AnswerDisplay.setStickerHTML(content);
                        break;
                    case Constant.TYPE_FILE:
                        contentHtml = AnswerDisplay.setFileHTML(content);
                        break;
                    case Constant.TYPE_LIST:
                        contentHtml = AnswerDisplay.setEcpListHTML(id);
                        break;
                    case Constant.TYPE_CARDS:
                        contentHtml = AnswerDisplay.setCardHTML(id);
                        break;
                    case Constant.TYPE_MEDIACARD:
                        contentHtml = AnswerDisplay.setMediaCardHTML(content);
                        break;
                    case Constant.TYPE_AUDIO:
                        contentHtml = AnswerDisplay.setAudioHTML(content);
                        break;
                    case Constant.TYPE_VIDEO:
                        contentHtml = AnswerDisplay.setVideoHTML(content);
                        break;
                    case Constant.TYPE_HTML:
                        contentHtml = AnswerDisplay.setHtmlHTML(content);
                        break;
                    case Constant.TYPE_QUICKREPLY:
                        contentHtml = AnswerDisplay.setQuickReplyHTML(content);
                        break;
                    default:
                        contentHtml = AnswerDisplay.setDefaultHtml(content);
                        break;
                }
				
				// 20220620 check restartchat display 
				if (typeof (content) !== "object") {
					if(content.indexOf("重啟交談") >= 0){
						var a = $("#RestartChatButton");
						a.removeClass('ButtonDisabled');
					}
				}
                
                if ((message.webViewUrl || content.WebViewUrl) && message.xiaoIType != 11)
                    WebChat.OpenP4Page(message.webViewUrl || content.WebViewUrl);
            }

            if (senderClass == "System") {
                if (!Util.isEmpty(content))
                    WebChat.addSystemMessage(content);
            } else {
                var html = AnswerDisplay.setChatMessage(senderClass, align, id, contentHtml, time, sender);
                $(html).appendTo(messageList);
                
                switch (type) {
                    case Constant.TYPE_LIST:
                        AnswerDisplay.appendListSwiper(id, content);
                        break;
                    case Constant.TYPE_CARDS:
                        AnswerDisplay.appendCardSwiper(id, content);
                        break;
                }

                if (message.type == Constant.TYPE_QUICKREPLY && !notSave) {
                    if (typeof (content) == "string")
                        QuickReply.initQuickReply(Util.JsonParse(message.content));
                    else
                        QuickReply.initQuickReply(content);
                }
            }
        }

        if (!notSave) {
            
            message.webViewUrl = "";
            
            message['disconnectStatus'] = id;
            if ('FCode' in message) {
                
                message['FCode'] = message.FCode;
            }
            WebChat.preMessageRecord.push(message);
        } else {
            
            if (message.hasOwnProperty('disconnectStatus')) {
                if (message.disconnectStatus.indexOf('true') != -1)
                    message['disconnectStatus'] = id + "_true";
                else
                    message['disconnectStatus'] = id + "_false";
            }
        }
        messageList.scrollTop = messageList.scrollHeight;
        return id;
    },

    refreshMessageListLayout: function () {
        let toolHeight = 0;
        let richmenuHeight = 0;
        let messagelistBottom = 0;
        let tool = $("#ToolZone");
        let editor = $("#EditorZone");
        let richmenu = $("#RichMenuImg");
        if (tool.is(":visible"))
            toolHeight = parseInt(tool.outerHeight());

        messagelistBottom = parseInt(editor.outerHeight());
        if (richmenu.is(":visible"))
            richmenuHeight = parseInt($("#RichMenuImg").height());

        $("#MessageList").css("bottom", richmenuHeight + toolHeight + messagelistBottom);
    },

    getFileIconClass: function (fileName) {
        var map = {
            "Excel": /\.(xls|xlsx)$/i,
            "Exe": /\.(exe|bat|cmd|sh|msi)$/i,
            "Image": /\.(bmp|gif|jpg|jpeg|png)$/i,
            "Ppt": /\.(ppt|pptx)$/i,
            "Text": /\.(txt|log)$/i,
            "Word": /\.(doc|docx)$/i,
            "Zip": /\.(7z|cab|gz|iso|jar|rar|tar|z|zip)$/i
        };
        for (var key in map) {
            if (map[key].test(fileName))
                return "ChatMessageFileContentIcon ChatMessageFileContentIcon" + key;
        }
        return "ChatMessageFileContentIcon";
    },

    getAvatar: function (senderClass) {
        var robottype = "A";
        var picId = "";
        switch (senderClass) {
            case "Robot":
                if (robottype == "A")
                    picId = (WebChat.tenantInfo.robotAPic == undefined) ? "0800c056-5000-dd54-020e-15c8b9722cd0" : WebChat.tenantInfo.robotAPic;
                if (robottype == "B")
                    picId = (WebChat.tenantInfo.robotBPic == undefined) ? "0800c056-5000-dd54-020e-15c8b974d5b0" : WebChat.tenantInfo.robotBPic;
                break;
            case "User":
                picId = (WebChat.tenantInfo.userIdPic == undefined) ? "0800c056-5000-dd54-020e-15c8b968de70" : WebChat.tenantInfo.userIdPic;
                break;
            case "Agent":
                picId = (WebChat.tenantInfo.agentIdPic == undefined) ? "0800c056-5000-dd54-020e-15c8b96569d0" : WebChat.tenantInfo.agentIdPic;
                break;
            case "Icr":
                picId = WebChat.tenantInfo.iCRIdPic;
                break;
        }
        return picId;
    },

    //-----------------------------------------------------------------------
    // other functions
    //-----------------------------------------------------------------------

    ajax: function (settings) {
        var success = settings.success;
        var error = settings.error;

        if (typeof error == "string") {
            var errorCode = error;
            error = settings.error = function () {
                WebChat.addSystemMessage(WebChat.text(errorCode), true);
            }
        }
        if (typeof success == "string") {
            var successCode = success;
            success = settings.success = function () {
                WebChat.addSystemMessage(WebChat.text(successCode));
            }
        }
        if (settings.method == null) {
            settings.method = "POST";
        }

        if (typeof settings.data == "object") {
            settings.data = JSON.stringify(settings.data);
        }
        settings.success = function (result) {
            WebChat.processAjaxResult(result, success, error);
        };
        $.ajax(settings);
    },

    processAjaxResult: function (result, success, error) {
        if (result._header_ != null && !result._header_.success) {
            if (error) {
                error(result._header_);
            }
        } else {
            if (success) {
                success(result);
                var messageList = document.getElementById("MessageList");
            }
        }
    },

    showHint: function (key) {
        switch (key) {
            case "attention":
                $("#HintModalTitle").html(WebChat.text("AttentionButtonText"));
                break;
            case "help":
                $("#HintModalTitle").html(WebChat.text("HelpButtonText"));
                break;
            case "version":
                $("#HintModalTitle").html(WebChat.text("VersionButtonText"));
                break;
            default:
                $("#HintModalTitle").html("");
        }

        $("#dvHintModalBody").html(WebChat.hintHtmlMap[key]);
        $("#HintModal").modal("show");
    },

    showSurvey: function () { //joanne
        if (WebChat.isEverInAgentService == true) {
            $("#SurveyAgentZone").css("display", "block");
        } else {
            $("#SurveyAgentZone").css("display", "none");
        }
        $("#SurveyModal").modal("show");
    },

    showHotTopic: function () {
        $("#HotTopicModal").modal("show");
    },

    processTextContent: function (text) {
        if (text == null) {
            text = "";
        }
        text = text.replace(/^\s+|\s+$/g, "").replace(/\n/g, "<br>")
            
            .replace(/\[link\s+action=['"](\w+)['"]\]([^\[]+)\[\/link\]/g, "<label action=\"$1\" onclick=\"LinkAction.doClick(event);\" tabindex=\"0\"  onkeypress=\"LinkAction.doClick(event);\">$2</label>")

            
            .replace(/\[link\](.*?)\[\/link\]/gi, "<label action=\"SendMessage\" onclick=\"LinkAction.doSendMessage('$1');\" tabindex=\"0\" onkeypress=\"LinkAction.doSendMessage('$1');\">$1</label>")

            
            .replace(/\[link\s+submit=[\'\"]+([^\[\]\'\"]+)[\'\"]+\s*[^\[\]]*\]([^\[\]]+)\[\/link\]/gi, "<label action=\"SendMessage\" onclick=\"LinkAction.doSendMessage('$1');\" tabindex=\"0\" onkeypress=\"LinkAction.doSendMessage('$1');\">$2</label>")
            .replace(/\[link\s+submit=([^\s\[\]\'\"]+)\s*[^\[\]]*\]([^\[\]]+)\[\/link\]/gi, "<label action=\"SendMessage\" onclick=\"LinkAction.doSendMessage('$1');\" tabindex=\"0\"  onkeypress=\"LinkAction.doSendMessage('$1');\">$2</label>")

            
            .replace(/\[link\s+url=[\'\"]+([^\[\]\'\"]+)[\'\"]+\s*[^\[\]]*\]([^\[\]]+)\[\/link\]/gi, "<label action=\"OpenUrl\" onclick=\"LinkAction.doOpenUrl('$1');\" tabindex=\"0\" onkeypress=\"LinkAction.doOpenUrl('$1');\">$2</label>")
            .replace(/\[link\s+url=([^\s\[\]\'\"]+)\s*[^\[\]]*\]([^\[\]]+)\[\/link\]/gi, "<label action=\"OpenUrl\" onclick=\"LinkAction.doOpenUrl('$1');\" tabindex=\"0\" onkeypress=\"LinkAction.doOpenUrl('$1');\">$2</label>")
            .replace(/(^|[^"'=])((https?|ftp|file):\/\/[-A-Za-z0-9+&@#\/%?=~_|!:,.;]+[-A-Za-z0-9+&@#\/%=~_|])/gi, "$1<label action=\"OpenUrl\" onclick=\"LinkAction.doOpenUrl('$2');\" tabindex=\"0\" onkeypress=\"LinkAction.doOpenUrl('$2');\">$2</label>")
            .replace(/(http|ftp|https)_/gi, "<label action=\"OpenUrl\" onclick=\"LinkAction.doOpenUrl('$1');\" tabindex=\"0\" onkeypress=\"LinkAction.doOpenUrl('$1');\">$1</label>")
            //.replace(/((https?|ftp|file):\/\/[-A-Za-z0-9+&@#\/%?=~_|!:,.;]+[-A-Za-z0-9+&@#\/%=~_|])/gi, "<label action=\"OpenUrl\" onclick=\"LinkAction.doOpenUrl('$1');\">$1</label>")

            
            .replace(/\[link\s+p4=[\'\"]+([^\[\]\'\"]+)[\'\"]+\s*[^\[\]]*\]([^\[\]]+)\[\/link\]/gi, "<label action=\"OpenUrl\" onclick=\"LinkAction.doOpenP4Url('$1');\" tabindex=\"0\" onkeypress=\"LinkAction.doOpenP4Url('$1');\">$2</label>")
            .replace(/\[link\s+p4=([^\s\[\]\'\"]+)\s*[^\[\]]*\]([^\[\]]+)\[\/link\]/gi, "<label action=\"OpenUrl\" onclick=\"LinkAction.doOpenP4Url('$1');\" tabindex=\"0\" onkeypress=\"LinkAction.doOpenP4Url('$1');\">$2</label>")

            
            .replace(/\<a\s+href=[\'\"]([^\[\]\'\"]+)([\'\"])/g, "<a href='$1' tabindex=\"0\" target='_blank' ")

            
            .replace(/\[emoji_0x([0-9a-fA-F]*)\]/g, '<img class="emoji" src="' + Util.getConfig('CRMGatewayUrl') + 'gateway/image/emoji/emoji_0x$1.png" alt=' + WebChat.text("EmojiButtonHint") + ' border="0" />');

        return text;
    },

    isButtonEnabled: function (element) {
        var button = $(typeof element == "string" ? "#" + element : element);
        return !button.hasClass("ButtonDisabled");
    },

    refreshButtonStatus: function () {
        if (WebChat.chatId == null && WebChat.isInQueue == false) {
            $("#SendButton").hide();
            $("#Editor").attr("disabled", "disabled");
        } else {
            $("#SendButton").show();
            $("#Editor").removeAttr("disabled");
            $("#SendButton").removeClass("SendButtonDisabled");
        }

        if (SurveyButton)
            $("#StopChatListItem").show();
        else
            $("#StopChatListItem").hide();

        if (WebChat.submitedSurvey == "all") {
            $("#SurveyListItem").hide();
        } else {
            if (WebChat.submitedSurvey == "robot" && !WebChat.isInAgentService || !Util.getConfig('isShowSurveyButton'))
                $("#SurveyListItem").hide();
            else
                $("#SurveyListItem").show();
        }

        if (WebChat.chatId != null && WebChat.isInAgentService)
            $("#StopChatListItem").show();
        else
            $("#StopChatListItem").hide();

        for (var id in WebChat.enableConditions) {
            if (eval(WebChat.enableConditions[id])) {
                $("#" + id).removeClass("ButtonDisabled");
            } else {
                $("#" + id).addClass("ButtonDisabled");
            }
        }
        WebChat.setEditorWidth();
    },

    setMessageFailed: function (elementId, failed) {
        var elementJq = $("#" + elementId);
        if (failed || arguments.length == 1) {
            console.debug(elementJq.find(".ChatMessageIcon").isEmpty)
            if (elementJq.find(".ChatMessageIcon").length == 0) {
                var html = "<div class=ChatMessageIcon title='" + WebChat.text("MessageSendFailed") + "'onclick=WebChat.disconnectIconClick(this);>";
                $(html).insertAfter(elementJq.find(".ChatMessageSenderName"));
            }
            
            WebChat.preMessageRecord.map(function (v) {
                if (v.disconnectStatus == elementId) {
                    v['disconnectStatus'] = elementId + '_true';
                }
            });
            elementJq.addClass("ChatMessageFailed");
        } else {
            elementJq.removeClass("ChatMessageFailed");
        }
    },

    leaveMessageContent: function () {
        var html = "";
        html.concat = "";
    },

    //-----------------------------------------------------------------------
    // websocket
    //-----------------------------------------------------------------------

    socketHandlers: {
        "agent/ready": "doSocketAgentReady",
        "message/send": "doSocketMessageSend",
        "agent/stop": "doSocketAgentStop",
        "chat/survey": "doSocketChatSurvey"
    },

    doSocketOpen: function () {
        //In order not to calculate the timeout.
        WebChat.chatId = WebChat.sessionStorage.getItem("chatId");
    },

    doSocketClose: function (reason) {
        console.debug('doSocketClose : socket closed: ' + JSON.stringify(reason));
        if (!WebChat.isNormalStop && WebChat.newMessageTime != null) {
            var now = new Date().getTime();
            var timeOut = (WebChat.isInAgentService) ? WebChat.tenantInfo.serviceTimeoutMinutes : WebChat.tenantInfo.chatTimeoutMinutes;

            if ((now - WebChat.newMessageTime) / 1000 / 60 > timeOut) {
                WebChat.chatId = null;
                WebChat.refreshButtonStatus();
            }
        }
    },

    doSocketError: function () {
        console.debug('web socket error');
        var message = {
            type: Constant.TYPE_TEXT,
            content: WebChat.text("WebsocketFailed")
        };
        elementId = WebChat.addMessage(message);
    },

    doSocketMessage: function (code, data) {
        console.debug("[jocket] %s, %o", code, data);
        var handler = WebChat[WebChat.socketHandlers[code]];
        if (handler == null) {
            console.error("unknown WebSocket data code: %s", code);
        } else {
            handler(data);
        }
    },

    sendRecievedMessage: function (data) {
        WebChat.ajax({
            url: Util.getConfig('CRMGatewayUrl') + "openapi/web/message/isReceived",
            data: {
                messageId: data.messageId,
                isReceived: true
            },
            async: false,
            error: null,
            success: function (ret) {
                console.debug("messageId: " + data.messageId + ", is confirmed: " + ret.confirmed);
            }
        });
    },

    doSocketAgentReady: function (data) {
        if (data.success) {
            WebChat.isInQueue = false;
            WebChat.queueZoneModal("hide");
            WebChat.sendRecievedMessage(data);
            WebChat.isInAgentService = true;
            let messageContent = {
                category: "cm",
                senderType: "agent",
                type: "Text",
                content: data.greeting,
            }

            if (data.sender)
                messageContent.sender = data.sender;

            WebChat.addMessage(messageContent);
            if (Util.getConfig('webCall'))
                WebCallStart.getChatroomInfo();
            WebChat.isEverInAgentService = true;
            WebChat.submitedSurvey = data.submitedSurvey;
        } else {
            
            LeaveWord.messageBox();
        }
        WebChat.refreshButtonStatus();
    },

    doSocketAgentStop: function (data) {
        console.debug("doSocketAgentStop : " + data);
        WebChat.stopEvent(data);
    },

    doSocketMessageSend: function (data) {
        data.category = (data.category || Constant.CATEGORY_CHAT).toLowerCase();
        if (data.category == "am") {
            data.category = Constant.CATEGORY_CHAT;
        }
        if (data.category == "sm" && data.content == "authRequest") {
            
            if (Util.getCookie('tokenId') != undefined) {
                data.content = WebChat.text("OtpVerified");
                data.senderType = Constant.SENDER_TYPE_AGENT;
                WebChat.addMessage(data);
            } else {
                Auth.doOtp();
            }
        } else if (data.category == "sm" && data.type == "Timeout") {
            var time = data.time.split(" ")[1];
            $(".timeout .ChatMessageTime").html(time);
            data.senderType = Constant.SENDER_TYPE_ROBOT;
            data.category = '';
            WebChat.addMessage(data);
        } else if (data.category == "sm" && data.hasOwnProperty("queueIndex")) {
            
            if (data.content != "") {
                $("#queueZoneModal .wording").text(data.content);
                WebChat.queueZoneModal("show");
            }
            if (!WebChat.isInQueue) {
                WebChat.isInQueue = true;
                WebChat.setQueueBtnStatus('show');
            }
        } else if (data.isNeedToLeaveMessage) {
            LeaveWord.messageBox(data.leaveMessageUrl);
            WebChat.sendRecievedMessage(data);
            return;
        } else if (data.category == "cm" && data.hasOwnProperty("leaveMessage")) {
            data.category = Constant.CATEGORY_CHAT;
            if (data.content == WebChat.tenantInfo.agentStopServiceWord) {
                $("#btnP4PageClose").click();
                WebChat.stopEvent();
            } else {
                WebChat.addMessage(data);
            }
        } else if (data.category === "cm" && data.type === "Timeout") {
            
            let content = Util.JsonParse(data.content);
            if (content.ans && content.ans.length > 0) {
                WebChat.addMultipleMessage(content, data, 'pushMessageTimeout')
                WebChat.stopEvent('pushMessageTimeout');
            } else {
                let messageObj = JSON.parse(JSON.stringify(data));
                messageObj.type = content.type;
                WebChat.addMessage(messageObj);
                WebChat.stopEvent('pushMessageTimeout');
            }
        } else if (data.content == WebChat.tenantInfo.notInServiceTimeHint || data.content == WebChat.tenantInfo.chatQueueFull) {
            
            WebChat.queueZoneModal("hide");
            WebChat.isInQueue = false;
        } else if (data.submitedSurvey == 'empty' || data.submitedSurvey == 'all' || data.submitedSurvey == 'robot') {
            
            WebChat.addMessage(data);
        } else {
            if (typeof (data.content) === 'string') {
                
                data.content = Util.unescapeHtml(data.content);
            }
            if (data.type === 'Multiple') {
                
                let parseContent = JSON.parse(data.content);
                WebChat.addMultipleMessage(parseContent, data, 'doSocketMessageSend')
            } else {
                WebChat.addMessage(data);
            }
        }
        
        WebChat.sendRecievedMessage(data);
    },

    addMultipleMessage: function (content, message, from) {
        content.ans.forEach(function (ansItem, index, array) {
            let newMessage = {};
            let deepAsnItem = JSON.parse(JSON.stringify(ansItem));
            delete deepAsnItem.type;

            if (ansItem.hasOwnProperty('WebViewUrl'))
                message['webViewUrl'] = ansItem.WebViewUrl;
            else
            if (ansItem.hasOwnProperty('QuickReply')) message['webViewUrl'] = ansItem.QuickReply.WebViewUrl

            if (message.xiaoIType) newMessage['xiaoIType'] = message.xiaoIType;

            newMessage['senderType'] = (from === 'greeting') ? Constant.SENDER_TYPE_ROBOT : message.senderType;
            newMessage['sender'] = message.sender || "";
            newMessage['messageTime'] = message.messageTime;
            newMessage['type'] = (ansItem.hasOwnProperty('QuickReply')) ? 'QuickReply' : ansItem.type
            newMessage['content'] = (ansItem.hasOwnProperty('QuickReply')) ? JSON.stringify(ansItem) : deepAsnItem
            WebChat.addMessage(newMessage);
        })
    },

    doSocketChatSurvey: function (data) {
        WebChat.isSurveyFromAgent = true;
        
        WebChat.submitedSurvey = data.submitedSurvey;
        WebChat.showSurvey();
        WebChat.stopChat(data);
    },

    sendPreviewMessage: function (text) {
        var messageJson = {
            type: Constant.TYPE_TEXT,
            content: text,
            chatId: WebChat.chatId,
            senderType: WebChat.tenantInfo.moduleType
        };

        WebChat.ajax({
            url: Util.getConfig('CRMGatewayUrl') + "openapi/web/previewmessage/send",
            data: messageJson,
            error: function () {
                console.debug('sendPreviewMessage error');
            },
            success: function (ret) {
                console.debug('sendPreviewMessage success');
            }
        });
    },

    //-----------------------------------------------------------------------
    // util functions
    //-----------------------------------------------------------------------
    text: function (code) {
        var text = WebChat.textResource[code] || code;
        for (var i = 1; i < arguments.length; ++i) {
            text = text.replace("${" + (i - 1) + "}", arguments[i]);
        }
        return text;
    },

    sessionStorage: {
        setItem: function (name, value) {
            if (WebChat.isStorage)
                sessionStorage.setItem(name, value);
        },

        getItem: function (name) {
            if (WebChat.isStorage) {
                var value = sessionStorage.getItem(name);
                return value;
            } else
                return null;
        },

        removeItem: function (name) {
            if (WebChat.isStorage)
                sessionStorage.removeItem(name);
        },

        clear: function () {
            if (WebChat.isStorage)
                sessionStorage.clear();
        }
    },

    clearTag: function (message) {
        messageTags = jQuery.parseHTML(message.replace(/\\(\W)/g, "$1"));
        retMessage = "";
        if (messageTags.length > 0) {
            if (messageTags.length == 1 && messageTags[0].tagName == undefined) {
                return Util.escapeHtml(message);
            }
            for (messageIndex in messageTags) {
                messageTag = messageTags[messageIndex];
                if (!WebChat.whileListTags.indexOf(messageTag.localName) == -1) {
                    if (messageTag.tagName == undefined) {
                        retMessage += Util.escapeHtml(messageTag.textContent);
                    } else {
                        retMessage += Util.escapeHtml("<" + messageTag.localName + ">");
                    }
                } else {
                    if (messageTag.outerHTML == undefined) {
                        retMessage += messageTag.textContent;
                    } else {
                        retMessage += messageTag.outerHTML;
                    }
                }
            }
            return retMessage;
        } else {
            return Util.escapeHtml(message);
        }
    },

    //解碼16key
	getQueryString: function(key){
		var obj = {}
		var len = location.search.slice(1).split("&").length;
		for(var i=0 ; i < len ; i++){
			var key = location.search.slice(1).split("&")[i].split("=")[0];
			var value= location.search.slice(1).split("&")[i].split("=")[1];
			obj[key]=value;
		}
		console.log(obj);
		console.log(obj["value"]);
		return obj["value"];
	},
};

window.onload = function () {

    if (!!Monitor.mode)
        Monitor.doLoad();
    else {
        
        WebChat.sendMsgByUrlContent = Util.getParameterByName('message') || '';
        WebChat.tenantCode = Config.tenantCode;
        WebChat.sessionStorage.setItem("tenantCode", WebChat.tenantCode);

        if (Config.useCustomConfig) {
            let configPath = "./custom/" + WebChat.tenantCode + "/CustomConfig.js";
            $.ajax({
                url: configPath,
                dataType: 'script',
                success: function (script) {
                    console.debug('%c %s', "font-weight:bold;  color: green;", '多租戶功能已啟用，已載入 ' + WebChat.tenantCode + ' 租戶設定檔！');
                    WebChat.doLoad();
                },
                error: function (error) {
                    if (error.status === 404)
                        console.debug('%c %s', "font-weight:bold;  color: red;", '警告！ 多租戶功能已啟用，查無此租戶設定檔，將採用系統設定檔！');
                    else
                        console.debug('%c %s', "font-weight:bold;  color: red;", 'Dynamic loading Error : ' + error);
                    WebChat.doLoad();
                },
            });
        } else {
            console.debug('%c %s', "font-weight:bold;  color: green;", '多租戶功能未啟用');
            WebChat.doLoad();
        }
    }
}

window.onbeforeunload = WebChat.doBeforeUnload;

document.ondragover = function (e) {
    e.preventDefault();
    e.returnValue = false;
};

document.ondrop = function (e) {
    e.preventDefault();
    e.returnValue = false;
};

window.addEventListener('message', function (e) {
    var data = e.data;
    if (data == "stopChat") {
        WebChat.stopChat();
    }
});